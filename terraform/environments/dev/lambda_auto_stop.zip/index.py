import boto3
import os
from datetime import datetime, timedelta

def handler(event, context):
    ec2 = boto3.client('ec2')
    cloudwatch = boto3.client('cloudwatch')

    project_tag = os.environ.get('PROJECT_TAG', 'APIM')
    environment_tag = os.environ.get('ENVIRONMENT_TAG', 'dev')
    cpu_threshold = float(os.environ.get('CPU_THRESHOLD', '5'))
    inactive_minutes = int(os.environ.get('INACTIVE_MINUTES', '30'))

    # Auto-discover instances by tags
    response = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:Project', 'Values': [project_tag]},
            {'Name': 'tag:Environment', 'Values': [environment_tag]},
            {'Name': 'instance-state-name', 'Values': ['running']}
        ]
    )

    running_instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            # Check if instance has AutoStop=false tag (skip those)
            auto_stop = True
            for tag in instance.get('Tags', []):
                if tag['Key'] == 'AutoStop' and tag['Value'].lower() == 'false':
                    auto_stop = False
                    break
            if auto_stop:
                running_instances.append(instance['InstanceId'])

    if not running_instances:
        print("No running instances found (or all have AutoStop=false)")
        return {'stopped': []}

    print(f"Found {len(running_instances)} running instances: {running_instances}")

    # Check CPU for each running instance
    instances_to_stop = []
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(minutes=inactive_minutes)

    for instance_id in running_instances:
        metrics = cloudwatch.get_metric_statistics(
            Namespace='AWS/EC2',
            MetricName='CPUUtilization',
            Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
            StartTime=start_time,
            EndTime=end_time,
            Period=300,
            Statistics=['Average']
        )

        if metrics['Datapoints']:
            avg_cpu = sum(d['Average'] for d in metrics['Datapoints']) / len(metrics['Datapoints'])
            print(f"Instance {instance_id}: avg CPU = {avg_cpu:.2f}%")

            if avg_cpu < cpu_threshold:
                instances_to_stop.append(instance_id)
        else:
            print(f"Instance {instance_id}: no metrics yet, skipping")

    # Stop idle instances
    if instances_to_stop:
        print(f"Stopping idle instances: {instances_to_stop}")
        ec2.stop_instances(InstanceIds=instances_to_stop)
        return {'stopped': instances_to_stop}

    return {'stopped': []}
