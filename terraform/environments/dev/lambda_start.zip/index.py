import boto3
import os

def handler(event, context):
    ec2 = boto3.client('ec2')
    project_tag = os.environ.get('PROJECT_TAG', 'APIM')
    environment_tag = os.environ.get('ENVIRONMENT_TAG', 'dev')
    alb_dns = os.environ.get('ALB_DNS', '')

    # Auto-discover stopped instances by tags
    response = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:Project', 'Values': [project_tag]},
            {'Name': 'tag:Environment', 'Values': [environment_tag]},
            {'Name': 'instance-state-name', 'Values': ['stopped']}
        ]
    )

    stopped_instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            stopped_instances.append(instance['InstanceId'])

    # Also check running instances
    running_response = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:Project', 'Values': [project_tag]},
            {'Name': 'tag:Environment', 'Values': [environment_tag]},
            {'Name': 'instance-state-name', 'Values': ['running']}
        ]
    )
    running_count = sum(len(r['Instances']) for r in running_response['Reservations'])

    if stopped_instances:
        print(f"Starting {len(stopped_instances)} instances: {stopped_instances}")
        ec2.start_instances(InstanceIds=stopped_instances)

        # Wait for instances to be running
        waiter = ec2.get_waiter('instance_running')
        waiter.wait(InstanceIds=stopped_instances, WaiterConfig={'Delay': 5, 'MaxAttempts': 24})

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': f'''
                <html>
                <head>
                    <meta http-equiv="refresh" content="90;url=http://{alb_dns}/gateway">
                    <style>
                        body {{ font-family: Arial; padding: 40px; background: #f5f5f5; }}
                        .container {{ background: white; padding: 30px; border-radius: 8px; max-width: 500px; margin: auto; }}
                        h1 {{ color: #2e7d32; }}
                        .loader {{ border: 4px solid #f3f3f3; border-top: 4px solid #2e7d32; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto; }}
                        @keyframes spin {{ 0% {{ transform: rotate(0deg); }} 100% {{ transform: rotate(360deg); }} }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>APIM Starting...</h1>
                        <div class="loader"></div>
                        <p><strong>{len(stopped_instances)}</strong> instance(s) starting</p>
                        <p>Please wait ~90 seconds for services to initialize...</p>
                        <p><a href="http://{alb_dns}/gateway">Click here if not redirected</a></p>
                    </div>
                </body>
                </html>
            '''
        }

    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': f'''
            <html>
            <head><meta http-equiv="refresh" content="3;url=http://{alb_dns}/gateway"></head>
            <body style="font-family: Arial; padding: 40px;">
                <h1 style="color: #2e7d32;">APIM Already Running</h1>
                <p>{running_count} instance(s) running</p>
                <p>Redirecting to gateway...</p>
            </body>
            </html>
        '''
    }
