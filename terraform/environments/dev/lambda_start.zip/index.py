import boto3
import os
import time

def handler(event, context):
    ec2 = boto3.client('ec2')
    instance_ids = os.environ['INSTANCE_IDS'].split(',')
    alb_dns = os.environ.get('ALB_DNS', '')

    # Get current state
    response = ec2.describe_instances(InstanceIds=instance_ids)

    stopped_instances = []
    running_instances = []

    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            if instance['State']['Name'] == 'stopped':
                stopped_instances.append(instance['InstanceId'])
            elif instance['State']['Name'] == 'running':
                running_instances.append(instance['InstanceId'])

    if stopped_instances:
        print(f"Starting instances: {stopped_instances}")
        ec2.start_instances(InstanceIds=stopped_instances)

        # Wait for instances to be running
        waiter = ec2.get_waiter('instance_running')
        waiter.wait(InstanceIds=stopped_instances, WaiterConfig={'Delay': 5, 'MaxAttempts': 24})

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': f'''
                <html>
                <head><meta http-equiv="refresh" content="60;url=http://{alb_dns}/gateway"></head>
                <body>
                    <h1>APIM Starting...</h1>
                    <p>Instances started: {stopped_instances}</p>
                    <p>Redirecting to gateway in 60 seconds...</p>
                    <p><a href="http://{alb_dns}/gateway">Click here if not redirected</a></p>
                </body>
                </html>
            '''
        }

    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'text/html'},
        'body': f'''
            <html>
            <head><meta http-equiv="refresh" content="3;url=http://{alb_dns}/gateway"></head>
            <body>
                <h1>APIM Already Running</h1>
                <p>Redirecting to gateway...</p>
            </body>
            </html>
        '''
    }
